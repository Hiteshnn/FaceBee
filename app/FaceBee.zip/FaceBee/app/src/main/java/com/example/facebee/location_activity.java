package com.example.facebee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
/*
public class location_activity extends AppCompatActivity {
    private Button button;
    private TextView tv;
    private static final int REQUEST_CODE_LOCATION_PERMISSION=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        button = (Button) findViewById(R.id.button);
        tv = (TextView) findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(location_activity.this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(location_activity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE_LOCATION_PERMISSION);
                }
                else{
                    getCurrentLocation();
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQUEST_CODE_LOCATION_PERMISSION&&grantResults.length>0){
            getCurrentLocation();
        }
        else{
            Toast.makeText(this,"Permission denied",Toast.LENGTH_SHORT).show();
        }
    }
    private void getCurrentLocation(){
        LocationRequest locationRequest=new LocationRequest();
    }
}
*/

public class location_activity extends AppCompatActivity implements LocationListener {
    private Button button;
    private TextView tv;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        button=(Button)findViewById(R.id.button);
        tv=(TextView)findViewById(R.id.textView);
        if(ContextCompat.checkSelfPermission(location_activity.this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(location_activity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},100);
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getLocation();
            }
        });

    }
    @SuppressLint("MissingPermission")
    private void getLocation(){
        try {
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, location_activity.this);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        }
    @Override
    public void onLocationChanged(@NonNull Location location) {
        tv.setText(location.getLatitude()+"\n"+ location.getLongitude()+"\n"+ location.getAltitude());
    }
}
