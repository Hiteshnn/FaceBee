package com.example.facebee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Forgotpw_activity extends AppCompatActivity {
    private TextView username;
    private EditText new_password,confirm_password;
    private Button change_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpw);
        getSupportActionBar().setTitle("Change password");
        username=(TextView)findViewById(R.id.f_username);
        change_password=(Button)findViewById(R.id.change_password);
        new_password=(EditText)findViewById(R.id.f_password);
        confirm_password=(EditText)findViewById(R.id.f_cpassword);
        change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Forgotpw_activity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}